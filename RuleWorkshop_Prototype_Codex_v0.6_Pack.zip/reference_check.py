"""Rule Workshop v0.6 finite design-reference checker.
Python 3.10+, standard library only: python reference_check.py
Uses the bundled authored JSON. Not a game runtime, Unity test, or general proof.
Derived from the uploaded v0.5 reference model, with new mechanics and new fixtures.
"""
from __future__ import annotations
import copy
import json
from pathlib import Path
from typing import Any

DIRECTIONS={'E':(1,0,0),'W':(-1,0,0),'N':(0,0,1),'S':(0,0,-1)}
PUSH_COMMANDS={'P'+d for d in DIRECTIONS}
SUBJECTS={'ROBOT','ROCK','CLOUD','SPRING','FLAG'}
PROPS={'YOU','PUSH','STOP','HOVER','FLY','WIN','BOUNCY'}
UP=(0,1,0); DOWN=(0,-1,0)
COMMANDS=[*DIRECTIONS,*sorted(PUSH_COMMANDS),'J','WAIT']
LEGACY_JUMPS={'JE','JW','JN','JS'}
ROOT=Path(__file__).resolve().parent

def add(a,b): return tuple(x+y for x,y in zip(a,b))

def levels():
    catalog=json.loads((ROOT/'catalog.json').read_text(encoding='utf-8'))
    if catalog['schemaVersion']!=6 or catalog['mechanicsVersion']!='RW-v0.6':
        raise ValueError('Unsupported catalog version')
    def xyz(c): return [c['x'],c['y'],c['z']]
    def extent(b):
        lo,hi=b['min'],b['max']
        return [lo['x'],hi['x'],lo['y'],hi['y'],lo['z'],hi['z']]
    result=[]
    for relative in catalog['levels']:
        path=(ROOT/relative).resolve()
        if ROOT not in path.parents: raise ValueError('Unsafe catalog path')
        raw=json.loads(path.read_text(encoding='utf-8'))
        if raw['schemaVersion']!=6 or raw['mechanicsVersion']!='RW-v0.6':
            raise ValueError('Explicit redesign required; legacy files are not v0.6')
        spec=dict(id=raw['id'],title=raw['title'],bounds=extent(raw['bounds']),
            solidBoxes=[extent(b) for b in raw['terrain']],
            entities=[dict(id=e['id'],kind=e['kind'].upper(),subject=e.get('subject',''),
                token=e.get('token',''),pos=xyz(e['cell']),anchored=e['anchored']) for e in raw['entities']],
            fixedRules=[' '.join(r['tokens']) for r in raw['fixedRules']],
            solution=raw['referenceSolution']['commands'],camera=raw['camera'],**raw['options'])
        for e in spec['entities']:
            if e['kind'] not in ('OBJECT','TEXT'): raise ValueError('Unknown entity kind')
            if e['kind']=='OBJECT' and (e['subject'] not in SUBJECTS or e['anchored']):
                raise ValueError('Invalid subject or hidden anchoring')
            if e['kind']=='TEXT' and e['token'] not in SUBJECTS|PROPS|{'IS','AND'}:
                raise ValueError('Unknown token')
        for line in spec['fixedRules']:
            if any(t not in SUBJECTS|PROPS|{'IS','AND'} for t in line.split()):
                raise ValueError('Unknown fixed token')
        if any(c not in COMMANDS for c in spec['solution']): raise ValueError('Invalid replay')
        assert spec['actionMode']=='MoveClimbHoldPush'
        assert spec['winMode']=='DistinctEntitiesSameCell'
        assert spec['gravityMode']=='WorldDownExceptHoverOrFly'
        assert spec['collisionMode']=='SolidPairsTerrainUniversal'
        assert spec['solidityMode']=='YouPushStopOrText'
        result.append(spec)
    return result

class _VictoryCommitted(Exception):
    """Internal short-circuit: stop a successful transaction at its winning microstep."""


class Model:
    """RW-v0.6 finite graybox witness model, not a complete Unity implementation.

    One YOU; implicit solid; default gravity. PUSH and STOP both imply solid.
    Dynamic collisions require both solids. Only terrain blocks all entities.
    Supported test layouts have a physical bottom; void death is not modeled.
    """
    def __init__(self, spec: dict[str, Any]):
        self.spec = copy.deepcopy(spec)
        self.entities = copy.deepcopy(spec['entities'])
        self.terrain: set[tuple[int,int,int]] = set()
        self.camera = 0
        self.log: list[dict[str, Any]] = []
        self.history: list[dict[str, Any]] = []
        self.apex: dict[str, dict[str, Any]] = {}
        self.forced_fall: set[str] = set()
        self.pressed: set[str] = set()
        self.won_latched = False
        self.win_record = None
        for x0,x1,y0,y1,z0,z1 in spec['solidBoxes']:
            self.terrain.update((x,y,z) for x in range(x0,x1+1)
                                for y in range(y0,y1+1) for z in range(z0,z1+1))
        ids = [e['id'] for e in self.entities]
        assert len(ids) == len(set(ids)), 'Duplicate entity ID'
        self.refresh()
        self.validate_state()
        actors = [e for e in self.entities if 'YOU' in self.props(e)]
        assert len(actors) == 1 and actors[0]['id'] == 'player', 'Checker supports one player.'
        assert self.solid(actors[0]) and self.gravity(actors[0]) == 'Down', 'Implicit player defaults required in these witnesses.'
        self.check_win('LevelLoaded', interrupt=False)

    def entity(self, eid):
        return next(e for e in self.entities if e['id'] == eid)

    def props(self, e):
        return self.rules.get(e.get('subject'),set()) if e['kind'] == 'OBJECT' else set()

    def refresh(self):
        rules = {c:set() for c in SUBJECTS}
        def parse(ts):
            if not ts or ts[0] not in SUBJECTS:
                return
            subjects = [ts[0]]; i = 1
            while i+1 < len(ts) and ts[i] == 'AND' and ts[i+1] in SUBJECTS:
                subjects.append(ts[i+1]); i += 2
            if i >= len(ts) or ts[i] != 'IS':
                return
            i += 1
            if i >= len(ts) or ts[i] not in PROPS:
                return
            properties = [ts[i]]; i += 1
            while i+1 < len(ts) and ts[i] == 'AND' and ts[i+1] in PROPS:
                properties.append(ts[i+1]); i += 2
            for subject in subjects:
                rules[subject].update(properties)
        for text in self.spec['fixedRules']:
            parse(text.split())
        tokens = {tuple(e['pos']): e['token'] for e in self.entities if e['kind'] == 'TEXT'}
        for p, token in tokens.items():
            if token not in SUBJECTS:
                continue
            for d in [(1,0,0),(0,0,1)]:
                q = p; ts = []
                while q in tokens:
                    ts.append(tokens[q]); q = add(q,d)
                parse(ts)
        self.rules = rules

    def solid(self, e):
        return e['kind'] == 'TEXT' or bool({'STOP','PUSH','YOU'} & self.props(e))

    def gravity(self, e):
        if e.get('anchored',False): return 'Anchored'
        if 'FLY' in self.props(e): return 'Up'
        if 'HOVER' in self.props(e): return 'Hover'
        return 'Down'

    def out(self, p):
        x0,x1,y0,y1,z0,z1 = self.spec['bounds']; x,y,z = p
        return not (x0 <= x <= x1 and y0 <= y <= y1 and z0 <= z <= z1)

    def blocks_pair(self, a, b):
        # Dynamic overlap is symmetric: only two effective solids exclude each other.
        # Terrain is checked separately and blocks all dynamic entities.
        return self.solid(a) and self.solid(b)

    def validate_state(self):
        cells={}
        for e in self.entities:
            p=tuple(e['pos'])
            assert not self.out(p), ('out of bounds',e['id'],p)
            assert p not in self.terrain, ('terrain overlap',e['id'],p)
            for other in cells.get(p,[]):
                assert not self.blocks_pair(e,other), ('illegal pair overlap',e['id'],other['id'],p)
            cells.setdefault(p,[]).append(e)

    def occupant(self, p, ignore=(), mover=None):
        if self.out(p) or p in self.terrain: return 'WALL'
        hits=[]
        for e in self.entities:
            if e['id'] in ignore or tuple(e['pos'])!=p: continue
            if (self.solid(e) if mover is None else self.blocks_pair(mover,e)): hits.append(e)
        return sorted(hits,key=lambda e:e['id'])[0] if hits else None

    def free(self, p, ignore=(), mover=None):
        return self.occupant(p, ignore, mover) is None

    def movable(self, e):
        # Player-induced displacement requires PUSH, including vertical bump/press.
        return (isinstance(e, dict) and not e.get('anchored',False)
                and (e['kind']=='TEXT' or 'PUSH' in self.props(e))
                and 'YOU' not in self.props(e))

    def event(self, kind, **fields):
        self.log.append({'event':kind, **fields})

    def check_win(self, cause, *, interrupt=True):
        if self.won_latched:
            return True
        actors = sorted((e for e in self.entities if 'YOU' in self.props(e)), key=lambda e:e['id'])
        goals = sorted((e for e in self.entities if 'WIN' in self.props(e)), key=lambda e:e['id'])
        pair = next(((a,b) for a in actors for b in goals
                     if a['id'] != b['id'] and a['pos'] == b['pos']), None)
        if pair is None:
            return False
        a,b = pair
        self.won_latched = True
        self.win_record = {'youId':a['id'], 'winId':b['id'], 'cell':list(a['pos']), 'cause':cause}
        self.event('Won', **self.win_record)
        if interrupt:
            raise _VictoryCommitted
        return True

    def commit(self, moves, reason):
        """Commit a whole push/head-bump/ride group, then parse+validate+check WIN.
        No victory evaluation is permitted between endpoints of the same atomic group.
        """
        staged = [(e, list(e['pos']), list(dest)) for e,dest in moves]
        for e,_,dest in staged:
            e['pos'] = dest
        for e,old,dest in staged:
            self.event(reason, id=e['id'], **{'from':old, 'to':dest})
        self.refresh()
        self.validate_state()
        self.check_win(reason)

    def shift(self, e, d, reason):
        self.commit([(e,add(tuple(e['pos']),d))], reason)

    def plan_push(self, first, d):
        chain=[]; current=first
        for _ in range(len(self.entities)+1):
            if not self.movable(current):
                return None
            chain.append(current)
            current=self.occupant(add(tuple(current['pos']),d), mover=current)
            if current is None:
                return chain
        raise AssertionError('Unexpected push chain cycle')

    def bounce(self, mover, surface):
        contact = list(mover['pos'])
        assert self.spec.get('bounceRiseCells',3) == 3
        self.event('BounceStarted',id=mover['id'],surfaceId=surface['id'],contactPos=contact,requestedRise=3)
        rose = 0
        for _ in range(3):
            if not self.free(add(tuple(mover['pos']),UP),ignore=(mover['id'],),mover=mover):
                break
            self.shift(mover,UP,'BounceStep'); rose += 1
        self.event('LandingBounce', id=mover['id'], surfaceId=surface['id'], contactPos=contact,
                   apexPos=list(mover['pos']), requestedRise=3, actualRise=rose)
        if rose:
            self.apex[mover['id']] = {'surfaceId':surface['id'], 'contactPos':contact,
                                     'apexPos':list(mover['pos']), 'riseCells':rose, 'resumeForcedFall':True}
            self.event('BounceApexReached',id=mover['id'],pos=list(mover['pos']))
        else:
            self.event('BounceBlocked',id=mover['id'],surfaceId=surface['id'])
        self.forced_fall.discard(mover['id'])

    def land(self, mover, allow_press=False):
        if mover['id'] in self.apex:
            return
        descended = False
        for _ in range(128):
            if mover['id'] not in self.forced_fall and self.gravity(mover) != 'Down':
                return
            dest = add(tuple(mover['pos']),DOWN)
            hit = self.occupant(dest,ignore=(mover['id'],),mover=mover)
            if hit is None:
                self.shift(mover,DOWN,'PlayerFell' if mover['id']=='player' else 'GravityFall')
                descended = True
                continue
            if isinstance(hit,dict) and not self.solid(hit):
                raise ValueError('Unsupported solid-to-hollow gravity contact in witness subset')
            if descended and isinstance(hit,dict) and 'BOUNCY' in self.props(hit):
                self.bounce(mover,hit)
                return
            if (descended and allow_press and mover['id'] not in self.pressed and self.movable(hit)
                    and self.free(add(tuple(hit['pos']),DOWN),mover=hit)):
                self.commit([(hit,add(tuple(hit['pos']),DOWN)),(mover,dest)],'LandingPress')
                self.pressed.add(mover['id'])
            self.forced_fall.discard(mover['id'])
            return
        raise AssertionError('Landing microstep cap')

    def _settle(self):
        seen = set(); player = self.entity('player')
        for _ in range(128):
            key = self.fingerprint()+repr(sorted(self.pressed))
            if key in seen:
                raise AssertionError('Automatic-resolution cycle')
            seen.add(key); before = key
            for e in sorted(self.entities,key=lambda v:(-v['pos'][1],v['id'])):
                if (e['kind']!='OBJECT' or e['id']=='player' or e['id'] in self.apex
                        or e['id'] in self.forced_fall or self.gravity(e) != 'Up'):
                    continue
                group = [e]
                if (self.solid(e) and 'player' not in self.apex
                        and tuple(player['pos'])==add(tuple(e['pos']),UP)):
                    group.append(player)
                ids = tuple(v['id'] for v in group)
                if all(self.free(add(tuple(v['pos']),UP),ignore=ids,mover=v) for v in group):
                    self.commit([(v,add(tuple(v['pos']),UP)) for v in group],'FlyOrRide')
            for e in sorted(self.entities,key=lambda v:(v['pos'][1],v['id'])):
                if e['id'] in self.apex:
                    continue
                forced = e['id'] in self.forced_fall
                natural = self.gravity(e) == 'Down'
                if forced or natural:
                    self.land(e,allow_press=(e['id']=='player'))
            if before == self.fingerprint()+repr(sorted(self.pressed)):
                return
        raise AssertionError('Resolution microstep cap')

    def settle(self):
        """Public fixture helper, not a hidden Unity update tick."""
        if self.won_latched:
            return
        try:
            self.refresh(); self.validate_state(); self.check_win('RulesResolved'); self._settle()
        except _VictoryCommitted:
            pass

    def won(self):
        return self.won_latched

    def phase(self):
        return 'Won' if self.won_latched else ('BounceApex' if 'player' in self.apex else 'Grounded')

    def snapshot(self):
        return {'entities':copy.deepcopy(sorted(self.entities,key=lambda e:e['id'])),'apex':copy.deepcopy(self.apex),
                'forcedFall':sorted(self.forced_fall),'won':self.won_latched,'winRecord':copy.deepcopy(self.win_record)}

    def restore(self, snapshot):
        self.entities = copy.deepcopy(snapshot['entities'])
        self.apex = copy.deepcopy(snapshot['apex'])
        self.forced_fall = set(snapshot['forcedFall'])
        self.won_latched = snapshot['won']; self.win_record = copy.deepcopy(snapshot['winRecord'])
        self.pressed.clear(); self.refresh(); self.validate_state()

    def fingerprint(self):
        return json.dumps(self.snapshot(),sort_keys=True)

    def undo(self):
        if not self.history:
            return False
        self.restore(self.history.pop()); return True

    def command(self, cmd):
        if cmd in ('CAM+','CAM-'):
            self.camera = (self.camera+(1 if cmd=='CAM+' else -1))%4
            return True
        if cmd in LEGACY_JUMPS:
            return False
        if cmd not in COMMANDS:
            raise ValueError(f'Unknown command: {cmd}')
        if self.won_latched:
            return False
        snap = self.snapshot(); oldlog = len(self.log)
        player = self.entity('player'); had_apex = 'player' in self.apex
        self.forced_fall.update(self.apex); self.apex.clear(); self.pressed.clear()
        success = False
        try:
            if had_apex:
                if cmd in ('WAIT','J'):
                    self.event('ApexReleased',id='player',steer=None); success=True
                elif cmd in DIRECTIONS:
                    d=DIRECTIONS[cmd]
                    if self.free(add(tuple(player['pos']),d),ignore=('player',),mover=player):
                        self.shift(player,d,'ApexSteer'); success=True
            elif cmd == 'J':
                up=add(tuple(player['pos']),UP); hit=self.occupant(up,mover=player)
                if hit is None:
                    self.shift(player,UP,'JumpApex'); success=True
                elif self.movable(hit) and self.free(add(up,UP),mover=hit):
                    self.commit([(hit,add(up,UP)),(player,up)],'HeadBump'); success=True
            elif cmd in DIRECTIONS or cmd in PUSH_COMMANDS:
                pushing=cmd in PUSH_COMMANDS
                d=DIRECTIONS[cmd[1:] if pushing else cmd]
                dest=add(tuple(player['pos']),d)
                hit=self.occupant(dest,mover=player)
                if hit is None:
                    self.shift(player,d,'PushModeWalk' if pushing else 'Walk'); success=True
                elif pushing:
                    chain=self.plan_push(hit,d)
                    if chain is not None:
                        self.commit([(e,add(tuple(e['pos']),d)) for e in chain]+[(player,dest)],'Pushed')
                        success=True
                elif (self.free(add(tuple(player['pos']),UP),ignore=('player',),mover=player)
                      and self.free(add(dest,UP),ignore=('player',),mover=player)):
                    # Climb is one atomic action. It is not downward contact or a free air jump.
                    self.commit([(player,add(dest,UP))],'Climbed'); success=True
            if not success:
                self.restore(snap); del self.log[oldlog:]; return False
            self.land(player,allow_press=True)
            self._settle()
        except _VictoryCommitted:
            success=True  # Valid terminal microstep: retain it; do not roll back or finish gravity.
        except Exception:
            self.restore(snap); del self.log[oldlog:]; raise
        self.history.append(snap)
        return success



def run_checks():
    """Finite rule/motion regression fixtures; not Unity/editor/input tests."""
    results=[]
    def check(name,fn):
        fn();results.append({'name':name,'passed':True})
    def ob(eid,s,p): return dict(id=eid,kind='OBJECT',subject=s,token='',pos=list(p),anchored=False)
    def tx(eid,t,p,a=False): return dict(id=eid,kind='TEXT',subject='',token=t,pos=list(p),anchored=a)
    def fixture(player=(0,1,0),extras=(),rules=(),boxes=()):
        return dict(id='fixture',bounds=[-4,9,0,12,-4,6],solidBoxes=[[-4,9,0,0,-4,6],*boxes],
                    entities=[ob('player','ROBOT',player),*copy.deepcopy(list(extras))],
                    fixedRules=['ROBOT IS YOU',*rules],bounceRiseCells=3)
    def expect_unchanged(m,cmd):
        before=m.fingerprint();n=len(m.history)
        assert not m.command(cmd)
        assert m.fingerprint()==before and len(m.history)==n
    def defaults():
        m=Model(fixture());p=m.entity('player')
        assert m.props(p)=={'YOU'} and m.solid(p) and m.gravity(p)=='Down' and not m.movable(p)
    check('YOU gives player solidity, not PUSH or visible FALL',defaults)
    def material_table():
        for rules,solid,push in [([],False,False),(['ROCK IS STOP'],True,False),
                (['ROCK IS PUSH'],True,True),(['ROCK IS PUSH AND STOP'],True,True)]:
            m=Model(fixture(extras=[ob('r','ROCK',(1,1,0))],rules=rules));r=m.entity('r')
            assert m.solid(r)==solid and m.movable(r)==push
    check('Neither/STOP/PUSH/both material truth table',material_table)
    def stop_falls():
        m=Model(fixture(extras=[ob('r','ROCK',(2,4,0))],rules=['ROCK IS STOP']));m.settle()
        assert m.entity('r')['pos']==[2,1,0]
    check('STOP does not anchor or cancel gravity',stop_falls)
    def push_falls():
        m=Model(fixture(extras=[ob('r','ROCK',(2,4,0))],rules=['ROCK IS PUSH']));m.settle()
        assert m.entity('r')['pos']==[2,1,0]
    check('PUSH objects have default downward gravity',push_falls)
    def hover():
        m=Model(fixture(extras=[ob('c','CLOUD',(2,4,0))],rules=['CLOUD IS HOVER']));m.settle()
        assert m.entity('c')['pos']==[2,4,0] and not m.solid(m.entity('c'))
    check('HOVER has no implicit solidity',hover)
    def ghost():
        m=Model(fixture(extras=[ob('c','CLOUD',(1,1,0))]));assert m.command('E')
        assert m.entity('player')['pos']==m.entity('c')['pos']==[1,1,0]
    check('Hollow objects can share the player cell',ghost)
    def pair_symmetric():
        m=Model(fixture(extras=[ob('r','ROCK',(1,1,0)),ob('f','FLAG',(2,1,0))],rules=['ROCK IS PUSH']))
        r,f=m.entity('r'),m.entity('f');assert not m.blocks_pair(r,f) and not m.blocks_pair(f,r)
        assert m.command('PE') and r['pos']==f['pos']==[2,1,0]
    check('Solid/non-solid dynamic overlap is symmetric, not a WIN exception',pair_symmetric)
    def terrain_blocks_ghost():
        m=Model(fixture(extras=[ob('f','FLAG',(2,4,0))],boxes=[[2,2,1,2,0,0]]));m.settle()
        assert m.entity('f')['pos']==[2,3,0]
    check('Terrain supports even non-solid falling objects',terrain_blocks_ghost)
    def move_climbs():
        m=Model(fixture(extras=[ob('r','ROCK',(1,1,0))],rules=['ROCK IS PUSH']));assert m.command('E')
        assert m.entity('r')['pos']==[1,1,0] and m.entity('player')['pos']==[1,2,0]
        assert not any(e['event']=='Pushed' for e in m.log)
    check('Normal direction climbs a PUSH rock without moving it',move_climbs)
    def explicit_push():
        m=Model(fixture(extras=[ob('r','ROCK',(1,1,0))],rules=['ROCK IS PUSH']));assert m.command('PE')
        assert m.entity('r')['pos']==[2,1,0] and m.entity('player')['pos']==[1,1,0]
    check('Push command moves object and player as one group',explicit_push)
    def stop_no_fallback():
        m=Model(fixture(extras=[ob('r','ROCK',(1,1,0))],rules=['ROCK IS STOP']))
        expect_unchanged(m,'PE');assert m.command('E') and m.entity('player')['pos']==[1,2,0]
    check('Failed push of STOP never falls back to climbing',stop_no_fallback)
    def push_empty():
        m=Model(fixture());assert m.command('PE') and m.entity('player')['pos']==[1,1,0]
    check('Push mode on empty ground gives flat movement',push_empty)
    def mixed_chain():
        m=Model(fixture(extras=[ob('r','ROCK',(1,1,0)),tx('t','AND',(2,1,0))],rules=['ROCK IS PUSH']))
        assert m.command('PE') and m.entity('r')['pos']==[2,1,0] and m.entity('t')['pos']==[3,1,0]
    check('Mixed word/rock PUSH chains use one contract',mixed_chain)
    def chain_blocked():
        m=Model(fixture(extras=[ob('r','ROCK',(1,1,0)),tx('t','AND',(2,1,0))],rules=['ROCK IS PUSH'],boxes=[[3,3,1,1,0,0]]))
        expect_unchanged(m,'PE')
    check('Blocked push chain makes no partial moves',chain_blocked)
    def anchored_word():
        m=Model(fixture(extras=[tx('t','AND',(1,1,0),True)]));expect_unchanged(m,'PE')
        assert m.command('E')
    check('Anchored text is not pushable but is climbable',anchored_word)
    def head_clear():
        m=Model(fixture(boxes=[[1,1,1,1,0,0],[0,0,2,2,0,0]]));expect_unchanged(m,'E')
    check('Climbing checks clearance above the starting body cell',head_clear)
    def tall_obstacle():
        m=Model(fixture(boxes=[[1,1,1,2,0,0]]));expect_unchanged(m,'E')
    check('Two-cell obstacle cannot be climbed from floor height',tall_obstacle)
    def no_cross_gap():
        m=Model(fixture(player=(0,3,0),boxes=[[0,0,1,2,0,0],[2,2,1,2,0,0]]))
        assert m.command('E') and m.entity('player')['pos']==[1,1,0]
    check('Normal movement into a gap falls; it is not a directional jump',no_cross_gap)
    def old_jump():
        m=Model(fixture())
        for cmd in LEGACY_JUMPS:expect_unchanged(m,cmd)
        assert m.command('J') and m.entity('player')['pos']==[0,1,0]
    check('Directional jumps absent; in-place jump returns in the same column',old_jump)
    def words_fall():
        m=Model(fixture(extras=[tx('t','AND',(2,4,0))]));m.settle()
        assert m.entity('t')['pos']==[2,1,0]
    check('Movable words use world gravity',words_fall)
    def top_push():
        m=Model(fixture(extras=[ob('r','ROCK',(0,2,0))],rules=['ROCK IS PUSH AND HOVER']))
        assert m.command('J') and m.entity('r')['pos']==[0,3,0]
    check('Head bump can raise a PUSH HOVER object',top_push)
    def top_stop():
        m=Model(fixture(extras=[ob('r','ROCK',(0,2,0))],rules=['ROCK IS STOP AND HOVER']))
        expect_unchanged(m,'J')
    check('STOP without PUSH cannot be displaced by a head bump',top_stop)
    def press():
        m=Model(fixture(player=(0,5,0),extras=[ob('r','ROCK',(0,2,0))],rules=['ROCK IS PUSH AND HOVER']))
        m.settle();assert m.entity('r')['pos']==[0,1,0]
        assert sum(e['event']=='LandingPress' and e.get('id')=='player' for e in m.log)==1
    check('Landing can press a PUSH HOVER object down once',press)
    def climb_no_bounce():
        m=Model(fixture(extras=[ob('s','SPRING',(1,1,0))],rules=['SPRING IS STOP AND BOUNCY']))
        assert m.command('E') and m.phase()=='Grounded' and m.entity('player')['pos']==[1,2,0]
        assert m.command('J') and m.phase()=='BounceApex' and m.entity('player')['pos']==[1,5,0]
    check('Climbing onto spring is not landing; jump then fall bounces three cells',climb_no_bounce)
    def bouncy_needs_solid():
        m=Model(fixture(extras=[ob('s','SPRING',(1,1,0))],rules=['SPRING IS BOUNCY']))
        assert m.command('E') and m.entity('player')['pos']==[1,1,0] and m.phase()=='Grounded'
    check('BOUNCY alone supplies no collision or support surface',bouncy_needs_solid)
    def bounce_pressure_priority():
        m=Model(fixture(player=(0,5,0),extras=[ob('r','ROCK',(0,2,0))],rules=['ROCK IS PUSH AND HOVER AND BOUNCY']))
        m.settle();assert m.entity('r')['pos']==[0,2,0] and m.entity('player')['pos']==[0,6,0]
        assert not any(e['event']=='LandingPress' for e in m.log)
    check('BOUNCY consumes landing before downward press',bounce_pressure_priority)
    def bounce_ceiling():
        m=Model(fixture(player=(0,2,0),extras=[ob('s','SPRING',(0,1,0))],rules=['SPRING IS STOP AND BOUNCY'],boxes=[[0,0,4,4,0,0]]))
        assert m.command('J') and m.phase()=='BounceApex' and m.entity('player')['pos']==[0,3,0]
        assert next(e for e in m.log if e['event']=='LandingBounce')['actualRise']==1
    check('Bounce checks each cell and truncates below a ceiling',bounce_ceiling)
    def apex_restrictions():
        m=Model(fixture(player=(0,2,0),extras=[ob('s','SPRING',(0,1,0)),ob('r','ROCK',(1,5,0))],
            rules=['SPRING IS STOP AND BOUNCY','ROCK IS PUSH AND HOVER']))
        assert m.command('J');expect_unchanged(m,'PE');expect_unchanged(m,'E')
        assert m.command('N') and m.entity('player')['pos']==[0,1,1] and m.phase()=='Grounded'
    check('Apex permits one clear side-step, never push or climb; rejection preserves apex',apex_restrictions)
    def neighbors():
        for d in [*DIRECTIONS.values(),UP,DOWN,(1,1,1)]:
            m=Model(fixture(player=(0,4,0),extras=[ob('g','FLAG',add((0,4,0),d))],rules=['FLAG IS WIN']))
            assert not m.won()
    check('Six face neighbors and diagonal do not win',neighbors)
    def win_enter():
        m=Model(fixture(extras=[ob('g','FLAG',(1,1,0))],rules=['FLAG IS WIN']));before=m.fingerprint()
        assert m.command('E') and m.won() and m.undo() and m.fingerprint()==before
    check('Enter hollow WIN; undo restores the entire winning command',win_enter)
    def win_fall():
        m=Model(fixture(extras=[ob('g','FLAG',(0,4,0))],rules=['FLAG IS WIN']));m.settle()
        assert m.won() and m.entity('g')['pos']==[0,1,0]
    check('Falling WIN can enter YOU and stops on the winning cell',win_fall)
    def material_win():
        m=Model(fixture(extras=[ob('g','FLAG',(1,1,0))],rules=['FLAG IS WIN AND PUSH']))
        assert m.command('E') and not m.won() and m.entity('player')['pos']==[1,2,0]
    check('WIN never overrides solidity supplied by PUSH',material_win)
    def same_identity():
        m=Model(fixture(rules=['ROBOT IS WIN']));assert not m.won()
    check('YOU WIN on one entity does not win against itself',same_identity)
    def grammar():
        es=[tx('a','ROCK',(0,2,2),True),tx('b','IS',(1,2,2),True),tx('c','PUSH',(2,2,2),True),
            tx('d','AND',(3,2,2),True)]
        m=Model(fixture(extras=es));assert m.rules['ROCK']=={'PUSH'}
        m.entities.append(tx('e','BOUNCY',(4,2,2),True));m.refresh();assert m.rules['ROCK']=={'PUSH','BOUNCY'}
    check('AND keeps a valid prefix and combines properties',grammar)
    def axes():
        for d,expected in [((1,0,0),True),((0,0,1),True),((-1,0,0),False),((0,1,0),False),((1,1,0),False)]:
            es=[tx(str(i),t,tuple(2+i*d[j] for j in range(3)),True) for i,t in enumerate(['ROCK','IS','PUSH'])]
            m=Model(fixture(extras=es));assert ('PUSH' in m.rules['ROCK'])==expected
    check('Only same-height +X and +Z sentences parse',axes)
    def grav_modes():
        m=Model(fixture(extras=[ob('c','CLOUD',(2,4,0))],rules=['CLOUD IS HOVER AND FLY']))
        assert m.gravity(m.entity('c'))=='Up'
        m.spec['fixedRules']=['ROBOT IS YOU','CLOUD IS HOVER'];m.refresh();assert m.gravity(m.entity('c'))=='Hover'
        m.spec['fixedRules']=['ROBOT IS YOU'];m.refresh();assert m.gravity(m.entity('c'))=='Down'
    check('Gravity resolves FLY > HOVER > default Down without stale properties',grav_modes)
    def ride():
        m=Model(fixture(player=(0,2,0),extras=[ob('c','CLOUD',(0,1,0))],rules=['CLOUD IS STOP AND FLY'],boxes=[[0,0,6,6,0,0]]))
        m.settle();assert m.entity('player')['pos']==[0,5,0] and m.entity('c')['pos']==[0,4,0]
    check('STOP FLY can carry player and stops the group below the ceiling',ride)
    def camera():
        m=Model(fixture());before=m.fingerprint()
        for _ in range(4):assert m.command('CAM+')
        assert m.fingerprint()==before and m.camera==0 and not m.history
    check('Camera rotation changes no world state or undo history',camera)
    return results


def main():
    import random
    reports=[]
    for spec in levels():
        m=Model(spec);initial=m.fingerprint();m.settle()
        assert m.fingerprint()==initial and not m.won(), ('unstable initial state',spec['id'])
        rows=[]
        for step,c in enumerate(spec['solution'],1):
            assert m.command(c), (spec['id'],step,c,'rejected')
            assert m.won()==(step==len(spec['solution'])), ('premature or missing win',spec['id'],step)
            rows.append(dict(step=step,command=c,player=m.entity('player')['pos'].copy(),phase=m.phase()))
        final=m.fingerprint()
        raw_path=ROOT/'levels'/f"{spec['id']}.json"
        raw=json.loads(raw_path.read_text(encoding='utf-8'))
        for event in raw['tutorial']['requiredWitnessEvents']:
            assert any(e['event']==event for e in m.log),(spec['id'],'missing required witness event',event)
        for _ in spec['solution']: assert m.undo()
        assert m.fingerprint()==initial and not m.history
        for seed in range(4):
            variant=copy.deepcopy(spec);random.Random(seed).shuffle(variant['entities'])
            mm=Model(variant)
            for c in variant['solution']: assert mm.command(c)
            assert mm.fingerprint()==final, ('entity insertion order changes result',spec['id'],seed)
        # Mark only the actual finite verification, never Unity/uniqueness claims.
        raw['referenceSolution']['status']='PythonWitnessPassed_NotUnityVerified'
        raw['referenceSolution']['expectedTrace']=rows
        raw_path.write_text(json.dumps(raw,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        reports.append(dict(id=spec['id'],passed=True,initialStable=True,wonAtLastCommand=True,
            undoRestoredInitial=True,entityOrderPermutations=4,trace=rows))
    checks=run_checks()
    result=dict(mechanicsVersion='RW-v0.6',levels=reports,localChecks=checks,
        summary=dict(levelWitnessesPassed=len(reports),localChecksPassed=len(checks)),
        limitations=['Not a Unity implementation, build or input test','No visual, camera-occlusion or usability test',
                     'Not an exhaustive solver, no shortest/unique/no-bypass guarantee',
                     'Finite bounded-tray layouts; advanced conflicts, multi-YOU and void deaths unsupported'])
    (ROOT/'validation_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result['summary'],ensure_ascii=False))
    print('Wrote validation_results.json; updated reference traces only, never layout coordinates.')


if __name__=='__main__':main()
