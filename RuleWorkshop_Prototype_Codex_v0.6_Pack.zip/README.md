# Rule Workshop v0.6 配套包

本包是设计规格与有限格子检查材料，不是 Unity 工程。

## 开始

将 `RuleWorkshop_Prototype_Codex_v0.6.md` 作为项目 `docs/PROTOTYPE_SPEC.md`。
本版新增明确的推动模式与普通移动登阶，并整合 PUSH / STOP 的实体性。
使用 `levels/` 下的六个新关卡，不把旧版 JSON 仅改版本号后继续执行。

- 主文档：完整规则、程序职责、编辑器要求、六关坐标和参考回放。
- `catalog.json`：关卡顺序。
- `levels/L01.json`—`L06.json`：schemaVersion=6、mechanicsVersion=RW-v0.6。
- `reference_check.py`：Python 3.10+ 标准库的有限设计检查器。
- `validation_results.json`：本次实际运行结果。
- `CHANGELOG.md`：相对 v0.5 的明确语义变更。

在本目录运行：

```bash
python reference_check.py
```

脚本会重写报告和 JSON 的参考验证状态／expectedTrace，不修改地形、实体坐标、规则或解法指令。
它不是所有复杂碰撞行为的通用模拟器，也不能替代 C# 的 EditMode/PlayMode 或手动试玩。

## 验证边界

本次六条参考解与 38 项局部检查已通过；每关初态稳定、末条指令才获胜、完整撤销恢复初态，实体插入顺序经过四次打乱重播。
没有执行 Unity 编译、实际输入、关卡编辑器 UI、镜头遮挡、独立构建或玩家测试；没有最短解、唯一解、无绕解证明。

参考命令 E/W/N/S 使用世界方向；PE/PW/PN/PS 是推动意图，不受相机槽影响。J 是原地跳；WAIT 是弹跳顶点原位恢复下降。

## 工程实施

以主文档为合同，沿用现有 Unity 2022 工程。保留用户资产与架构边界，不把参考 Python 直接当成完整 C# 工程。
`player`、`goal` 是本包测试数据的稳定 ID，正式模拟必须按 YOU/WIN 属性识别，不按名字识别角色和终点。
